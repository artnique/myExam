﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FlatPlanet.Service;

namespace FlatPlanet.Controllers
{
    public class HomeController : Controller
    {

        //
        // GET: /Home/
        [HttpGet]
        public ActionResult Index()
        {
            int cCounter = 0;
            ServiceLayer dt = new ServiceLayer();
            bool IsValid = dt.isValidConnection();
            ViewBag.ValidConnection = IsValid;

            if (IsValid)
            {
                cCounter = dt.GetCurrentCount();
            }
            ViewBag.Counter = cCounter;
            dt = null;

            return View();
        }

        [HttpPost]
        public ActionResult Index(string i)
        {
            int cCounter = 0;
            ServiceLayer dt = new ServiceLayer();
            bool IsValid = dt.isValidConnection();
            ViewBag.ValidConnection = IsValid;

            if (IsValid)
            {
                cCounter = dt.GetCurrentCount();

                if(cCounter < 10)
                {
                    dt.AddCounter();
                    cCounter++;
                }
            }
            ViewBag.Counter = cCounter;
            dt = null;

            return View();
        }


    }
}
