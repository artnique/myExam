﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace FlatPlanet.Service
{
    public class ServiceLayer : DataLayer
    {
        public int GetCurrentCount()
        {
            int Result;
            SqlCommand sqlCOM = new SqlCommand();

            sqlCOM.CommandText = " Select ISNULL(fldCounter,0) From tblCounter ";

            Result = Convert.ToInt32(base.GetValue(sqlCOM));

            sqlCOM = null;
            return Result;
        }

        public int AddCounter()
        {
            int Result;
            SqlCommand sqlCOM = new SqlCommand();

            sqlCOM.CommandText = " Update tblCounter Set fldCounter = (fldCounter + 1) ";

            Result = Convert.ToInt32(base.GetValue(sqlCOM));

            sqlCOM = null;
            return Result;
        }
    }
}