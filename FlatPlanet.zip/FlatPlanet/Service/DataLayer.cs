﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace FlatPlanet.Service
{
    #region Data Layer
    public class DataLayer
    {
        private string ConnectionString()
        {
            string dbServer = System.Configuration.ConfigurationManager.AppSettings["dbServer"];
            string dbDatabase = System.Configuration.ConfigurationManager.AppSettings["dbDatabase"];
            string dbUser = System.Configuration.ConfigurationManager.AppSettings["dbUser"];
            string dbPassword = System.Configuration.ConfigurationManager.AppSettings["dbPassword"];
            return "Data Source=" + dbServer + ";" +
                   "Initial Catalog=" + dbDatabase + ";" +
                   "User ID=" + dbUser + ";" +
                   "Password=" + dbPassword + "";
        }


        public bool isValidConnection()
        {
            SqlConnection sqlCN = new SqlConnection(this.ConnectionString());
            try
            {
                sqlCN.Open();
                sqlCN.Close();
                sqlCN = null;
                return true;
            }
            catch
            {
                return false;
            }
        }

        public int Execute(SqlCommand SQLCom)
        {
            int AffectedRows;

            SQLCom.CommandType = CommandType.StoredProcedure;
            SQLCom.Connection = new SqlConnection(this.ConnectionString());
            SQLCom.CommandTimeout = 600;

            SQLCom.Connection.Open();
            AffectedRows = SQLCom.ExecuteNonQuery();
            SQLCom.Connection.Close();

            SQLCom = null;

            return AffectedRows;
        }

        public object GetValue(SqlCommand SQLCom)
        {
            object Result;

            SQLCom.CommandType = CommandType.Text;
            SQLCom.Connection = new SqlConnection(this.ConnectionString());

            SQLCom.Connection.Open();
            Result = SQLCom.ExecuteScalar();
            SQLCom.Connection.Close();

            SQLCom = null;

            if (Result == null)
            {
                return 0;
            }
            else
            {
                return Result;
            }
        }

    }
    #endregion
}